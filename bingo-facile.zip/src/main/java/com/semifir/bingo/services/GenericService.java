package com.semifir.bingo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;

public abstract class GenericService<T, ID> {

	@Autowired
	private JpaRepository<T, ID> repository;
	
	public T save(T entity) {
		return this.repository.save(entity);
	}
	
	public List<T> findAll(){
		return this.repository.findAll();
	}
}

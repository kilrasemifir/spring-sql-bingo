package com.semifir.bingo.services;

import org.springframework.stereotype.Service;

import com.semifir.bingo.models.User;

@Service
public class UserService extends GenericService<User, Long>{

}

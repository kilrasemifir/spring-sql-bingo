package com.semifir.bingo.models;

public class Campaign {

}

package com.semifir.bingo.models;

public class Category {

}
